package steps;

import io.cucumber.java.pt.Dado;
import pageObjects.InitialPage;
import pageObjects.PrincipalPage;
import utils.Utils;

import static utils.Utils.driver;

import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;

public class DespesasSteps {



	@Dado("^que o usuario esta na tela principal$")
	public void queOUsuarioEstaNaTelaPrincipal() throws Throwable {
		InitialPage ip = new InitialPage(driver);
		ip.clicarParaContinuarSemConta();
		ip.clicarParaContinuarSemConta();
		ip.clicarParaComecar();
		ip.clicarProximo();
		ip.saldoInicial("1000");
		ip.clicarProximo();
		
	}

	@Quando("^o usuario acionar o botao Adicionar Gasto$")
	public void oUsuarioAcionarOBotaoAdicionarGasto() throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.clicarParaAdicionarGasto();
	}
	
	@Quando("^passa pelo tutorial$")
	public void ePassaPeloTutorial() {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.pularTutorial();
	}

	@Quando("^adiciona o gasto de (\\d+)$")
	public void adicionaOGastoDe(int arg1) throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.adicionarGasto(Integer.toString(arg1));
	}

	
	@Quando("^seleciona Transporte$")
	public void selecionaTransporte() throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.selecionaTransporte();
	}

	@Quando("^confirma o gasto$")
	public void confirmaOGasto() throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		Utils.scrollToBottom();
		pp.confirmarAdicionarGasto();
	}

	@Entao("^o app mostra um saldo de 900$")
	public void oAppMostraUmSaldoDe900() throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.confirmaSaldoDe900();
	}

	@Entao("^o app mostra um saldo de 0$")
	public void oAppMostraUmSaldoDe0() throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.confirmaSaldoDe0();
	}

	@Entao("^o app mostra um saldo de -500$")
	public void oAppMostraUmSaldoDe500Negativo(int arg1) throws Throwable {
		PrincipalPage pp = new PrincipalPage(driver);
		pp.confirmaSaldoDe500Negativo();
	}
}

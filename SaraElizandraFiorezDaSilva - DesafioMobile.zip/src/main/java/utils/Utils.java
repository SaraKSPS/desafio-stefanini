package utils;

import static utils.Utils.driver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.cucumber.core.api.Scenario;

public class Utils {

	public static AppiumDriver<WebElement> driver;

	public static void acessarApp() throws MalformedURLException, InterruptedException {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		/*
		 * { "platformName": "android", "deviceName": "emulator-5556", "appPackage":
		 * "ru.innim.my_finance", "appActivity": "ru.innim.my_finance.MainActivity" }
		 */
		desiredCapabilities.setCapability("platformName", "Android");
		desiredCapabilities.setCapability("deviceName", "emulator-5556");
		desiredCapabilities.setCapability("automationName", "uiAutomator2");
		desiredCapabilities.setCapability("appPackage", "ru.innim.my_finance");
		desiredCapabilities.setCapability("appActivity", "ru.innim.my_finance.MainActivity");
		// desiredCapabilities.setCapability("noReset", "true");

		driver = new AppiumDriver<WebElement>(new URL("http://localhost:4723/wd/hub"), desiredCapabilities);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	public static File gerarScreenShot(Scenario cenario) {
		final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		cenario.embed(screenshot, "image/png");
		File imagem = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {

			FileUtils.copyFile(imagem,
					(new File("./target/screenshots", cenario.getName() + "-" + cenario.getStatus() + ".png")));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return imagem;

	}

	public static void inputTextAppiumCommand(MobileElement elemento, String keyeventCommand) {

		elemento.click();

		List<String> argsCommandKeyevent = Arrays.asList("text", transformarNome(keyeventCommand));
		Map<String, Object> commandKeyevent = ImmutableMap.of("command", "input", "args", argsCommandKeyevent);

		String output = (String) driver.executeScript("mobile: shell", commandKeyevent);

		System.out.println(output);

	}

	public static String transformarNome(String texto) {
		String[] lista = texto.split(" ");

		String stringModificada = "";

		for (String palavra : lista) {
			stringModificada += palavra + "%s";

		}

		if (stringModificada.length() > 0) {
			stringModificada = stringModificada.substring(0, stringModificada.length() - 2);
		}

		return stringModificada;

	}

	// http://code2test.com/appium-tutorial/vertical-and-horizontal-swipe-scroll-in-appium/
	public static void scrollToBottom() {

		TouchAction action = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int width = size.width;
		int height = size.height;
		int middleOfX = width / 2;
		int startYCoordinate = (int) (height * .7);
		int endYCoordinate = (int) (height * .2);

		action.press(PointOption.point(middleOfX, startYCoordinate))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
				.moveTo(PointOption.point(middleOfX, endYCoordinate)).release().perform();

		action.press(PointOption.point(middleOfX, startYCoordinate))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
				.moveTo(PointOption.point(middleOfX, endYCoordinate)).release().perform();
	}

}

package pageObjects;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import static utils.Utils.*;

public class InitialPage {
	 public InitialPage(AppiumDriver<?> driver) {
		 	PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	

	@AndroidFindBy(accessibility = "Continuar sem criar uma conta")
	private MobileElement continuarSemConta;
	
	@AndroidFindBy(accessibility = "Come�ar")
	private MobileElement comecarBtn;
	
	@AndroidFindBy(accessibility = "D�lar americano USD")
	private MobileElement dolar;
	
	@AndroidFindBy(accessibility = "Pr�ximo")
	private MobileElement proximoBtn;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText")
	private MobileElement saldoInicial;
	
	public void clicarParaContinuarSemConta() {
		continuarSemConta.click();
	}

	public void clicarParaComecar() {
		comecarBtn.click();
	}

	public void selecionarUSD() {
		dolar.click();
	}
	
	public void clicarProximo() {
		proximoBtn.click();
	}
	
	public void saldoInicial(String valor) {
		inputTextAppiumCommand(saldoInicial, valor);
	}
	
}

$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Features/Checkout.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Checkout",
  "description": "",
  "id": "checkout",
  "keyword": "Funcionalidade",
  "tags": [
    {
      "line": 2,
      "name": "@Checkout"
    },
    {
      "line": 2,
      "name": "@End2End"
    }
  ]
});
formatter.before({
  "duration": 3004910100,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 1733194700,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 792656400,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Overview da compra de um item",
  "description": "",
  "id": "checkout;overview-da-compra-de-um-item",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 9,
      "name": "@Checkout"
    },
    {
      "line": 9,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "clicar no botao de adicionar um item no carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 12,
  "name": "clicar no icone do carrinho",
  "keyword": "E "
});
formatter.step({
  "line": 13,
  "name": "clicar em Checkout",
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "colocar valores validos para nome, sobrenome e cep",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "clicar para prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 16,
  "name": "a tela de checkout overview deve ser mostrada com o valor total correto do item",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_de_adicionar_um_item_no_carrinho()"
});
formatter.result({
  "duration": 66458400,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_no_icone_do_carrinho()"
});
formatter.result({
  "duration": 94484600,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_em_Checkout()"
});
formatter.result({
  "duration": 140659900,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.colocar_valores_validos_para_nome_sobrenome_e_cep()"
});
formatter.result({
  "duration": 306986600,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_prosseguir()"
});
formatter.result({
  "duration": 102497100,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.a_tela_de_checkout_overview_deve_ser_mostrada_com_o_valor_total_correto_do_item()"
});
formatter.result({
  "duration": 65514700,
  "status": "passed"
});
formatter.after({
  "duration": 909476800,
  "status": "passed"
});
formatter.before({
  "duration": 1582575100,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 464176600,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 853556900,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Overview da compra de todos os itens",
  "description": "",
  "id": "checkout;overview-da-compra-de-todos-os-itens",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 18,
      "name": "@Checkout"
    },
    {
      "line": 18,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 20,
  "name": "clicar para adicionar todos os itens ao carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 21,
  "name": "clicar no icone do carrinho",
  "keyword": "E "
});
formatter.step({
  "line": 22,
  "name": "clicar em Checkout",
  "keyword": "E "
});
formatter.step({
  "line": 23,
  "name": "colocar valores validos para nome, sobrenome e cep",
  "keyword": "E "
});
formatter.step({
  "line": 24,
  "name": "clicar para prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 25,
  "name": "a tela de checkout overview deve ser mostrada com o valor total correto de todos os itens",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_para_adicionar_todos_os_itens_ao_carrinho()"
});
formatter.result({
  "duration": 791472100,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_no_icone_do_carrinho()"
});
formatter.result({
  "duration": 162300500,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_em_Checkout()"
});
formatter.result({
  "duration": 121538700,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.colocar_valores_validos_para_nome_sobrenome_e_cep()"
});
formatter.result({
  "duration": 370206900,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_prosseguir()"
});
formatter.result({
  "duration": 109363600,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.a_tela_de_checkout_overview_deve_ser_mostrada_com_o_valor_total_correto_de_todos_os_itens()"
});
formatter.result({
  "duration": 67618600,
  "status": "passed"
});
formatter.after({
  "duration": 849372100,
  "status": "passed"
});
formatter.before({
  "duration": 1631752500,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 473532900,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 825638600,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Compra de um item",
  "description": "",
  "id": "checkout;compra-de-um-item",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 27,
      "name": "@Checkout"
    },
    {
      "line": 27,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "clicar no botao de adicionar um item no carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 30,
  "name": "clicar no icone do carrinho",
  "keyword": "E "
});
formatter.step({
  "line": 31,
  "name": "clicar em Checkout",
  "keyword": "E "
});
formatter.step({
  "line": 32,
  "name": "colocar valores validos para nome, sobrenome e cep",
  "keyword": "E "
});
formatter.step({
  "line": 33,
  "name": "clicar para prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 34,
  "name": "clicar para concluir o pedido",
  "keyword": "E "
});
formatter.step({
  "line": 35,
  "name": "a tela de sucesso ao realizar ordem deve ser exibida",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_de_adicionar_um_item_no_carrinho()"
});
formatter.result({
  "duration": 172525000,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_no_icone_do_carrinho()"
});
formatter.result({
  "duration": 242243700,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_em_Checkout()"
});
formatter.result({
  "duration": 134954600,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.colocar_valores_validos_para_nome_sobrenome_e_cep()"
});
formatter.result({
  "duration": 354746200,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_prosseguir()"
});
formatter.result({
  "duration": 111578400,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_concluir_o_pedido()"
});
formatter.result({
  "duration": 99050300,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.a_tela_de_sucesso_ao_realizar_ordem_deve_ser_exibida()"
});
formatter.result({
  "duration": 66819500,
  "status": "passed"
});
formatter.after({
  "duration": 864690000,
  "status": "passed"
});
formatter.before({
  "duration": 1580839400,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 449503700,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 816685200,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Compra de todos os itens",
  "description": "",
  "id": "checkout;compra-de-todos-os-itens",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 37,
      "name": "@Checkout"
    },
    {
      "line": 37,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 39,
  "name": "clicar para adicionar todos os itens ao carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 40,
  "name": "clicar no icone do carrinho",
  "keyword": "E "
});
formatter.step({
  "line": 41,
  "name": "clicar em Checkout",
  "keyword": "E "
});
formatter.step({
  "line": 42,
  "name": "colocar valores validos para nome, sobrenome e cep",
  "keyword": "E "
});
formatter.step({
  "line": 43,
  "name": "clicar para prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 44,
  "name": "clicar para concluir o pedido",
  "keyword": "E "
});
formatter.step({
  "line": 45,
  "name": "a tela de sucesso ao realizar ordem deve ser exibida",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_para_adicionar_todos_os_itens_ao_carrinho()"
});
formatter.result({
  "duration": 794616200,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_no_icone_do_carrinho()"
});
formatter.result({
  "duration": 274901500,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_em_Checkout()"
});
formatter.result({
  "duration": 124468600,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.colocar_valores_validos_para_nome_sobrenome_e_cep()"
});
formatter.result({
  "duration": 313161700,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_prosseguir()"
});
formatter.result({
  "duration": 101217800,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_concluir_o_pedido()"
});
formatter.result({
  "duration": 76890800,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.a_tela_de_sucesso_ao_realizar_ordem_deve_ser_exibida()"
});
formatter.result({
  "duration": 63982100,
  "status": "passed"
});
formatter.after({
  "duration": 846014700,
  "status": "passed"
});
formatter.before({
  "duration": 1633861200,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 521430000,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 811356700,
  "status": "passed"
});
formatter.scenario({
  "line": 48,
  "name": "Comprar sem nenhum item",
  "description": "",
  "id": "checkout;comprar-sem-nenhum-item",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 47,
      "name": "@Checkout"
    },
    {
      "line": 47,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 49,
  "name": "clicar no icone do carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 50,
  "name": "clicar em Checkout",
  "keyword": "E "
});
formatter.step({
  "line": 51,
  "name": "colocar valores validos para nome, sobrenome e cep",
  "keyword": "E "
});
formatter.step({
  "line": 52,
  "name": "clicar para prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 53,
  "name": "clicar para concluir o pedido",
  "keyword": "E "
});
formatter.step({
  "line": 54,
  "name": "a tela de sucesso ao realizar ordem nao deveria ser exibida",
  "keyword": "Entao "
});
formatter.match({
  "location": "CheckoutSteps.clicar_no_icone_do_carrinho()"
});
formatter.result({
  "duration": 85490700,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_em_Checkout()"
});
formatter.result({
  "duration": 138813700,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.colocar_valores_validos_para_nome_sobrenome_e_cep()"
});
formatter.result({
  "duration": 403696200,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_prosseguir()"
});
formatter.result({
  "duration": 150438500,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.clicar_para_concluir_o_pedido()"
});
formatter.result({
  "duration": 91479100,
  "status": "passed"
});
formatter.match({
  "location": "CheckoutSteps.aTelaDeSucessoAoRealizarOrdemNaoDeveriaSerExibida()"
});
formatter.result({
  "duration": 39566200,
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:87)\r\n\tat org.junit.Assert.assertTrue(Assert.java:42)\r\n\tat org.junit.Assert.assertFalse(Assert.java:65)\r\n\tat org.junit.Assert.assertFalse(Assert.java:75)\r\n\tat pageobjects.CheckoutCompletePage.verificarOrdemInsucesso(CheckoutCompletePage.java:30)\r\n\tat stepdefinitions.CheckoutSteps.aTelaDeSucessoAoRealizarOrdemNaoDeveriaSerExibida(CheckoutSteps.java:72)\r\n\tat ✽.Entao a tela de sucesso ao realizar ordem nao deveria ser exibida(Features/Checkout.feature:54)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 924486000,
  "status": "passed"
});
formatter.uri("Features/Details.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Detalhes",
  "description": "",
  "id": "detalhes",
  "keyword": "Funcionalidade",
  "tags": [
    {
      "line": 2,
      "name": "@Logout"
    },
    {
      "line": 2,
      "name": "@End2End"
    }
  ]
});
formatter.before({
  "duration": 1570829500,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.step({
  "line": 8,
  "name": "tela de algum item esteja sendo exibida",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 479060500,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 841909800,
  "status": "passed"
});
formatter.match({
  "location": "DetailsSteps.telaDeAlgumItemEstejaSendoExibida()"
});
formatter.result({
  "duration": 101024000,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Adicionar um item ao Carrinho pelos Detalhes",
  "description": "",
  "id": "detalhes;adicionar-um-item-ao-carrinho-pelos-detalhes",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 10,
      "name": "@Detalhes"
    },
    {
      "line": 10,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "clica para adicionar item pelos detalhes",
  "keyword": "Quando "
});
formatter.step({
  "line": 13,
  "name": "o sistema devera mostrar no carrinho o numero 1",
  "keyword": "Entao "
});
formatter.match({
  "location": "DetailsSteps.clicaParaAdicionarItemPelosDetalhes()"
});
formatter.result({
  "duration": 81183800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 46
    }
  ],
  "location": "InventorySteps.o_sistema_devera_mostrar_no_carrinho_o_numero(int)"
});
formatter.result({
  "duration": 46023500,
  "status": "passed"
});
formatter.after({
  "duration": 871719400,
  "status": "passed"
});
formatter.uri("Features/Inventory.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Inventario",
  "description": "",
  "id": "inventario",
  "keyword": "Funcionalidade",
  "tags": [
    {
      "line": 2,
      "name": "@Inventory"
    },
    {
      "line": 2,
      "name": "@End2End"
    }
  ]
});
formatter.before({
  "duration": 1681132300,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 482003500,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 1251046800,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Adicionar um item ao Carrinho",
  "description": "",
  "id": "inventario;adicionar-um-item-ao-carrinho",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 9,
      "name": "@Carrinho"
    },
    {
      "line": 9,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "clicar no botao de adicionar um item no carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 12,
  "name": "o sistema devera mostrar no carrinho o numero 1",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_de_adicionar_um_item_no_carrinho()"
});
formatter.result({
  "duration": 62086200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 46
    }
  ],
  "location": "InventorySteps.o_sistema_devera_mostrar_no_carrinho_o_numero(int)"
});
formatter.result({
  "duration": 38936500,
  "status": "passed"
});
formatter.after({
  "duration": 852111200,
  "status": "passed"
});
formatter.before({
  "duration": 1603879800,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 599578200,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 1292107400,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "Remover um item no Carrinho",
  "description": "",
  "id": "inventario;remover-um-item-no-carrinho",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 14,
      "name": "@Carrinho"
    },
    {
      "line": 14,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 16,
  "name": "clicar no botao de adicionar um item no carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 17,
  "name": "o sistema devera mostrar nenhum numero no carrinho",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_de_adicionar_um_item_no_carrinho()"
});
formatter.result({
  "duration": 119661200,
  "status": "passed"
});
formatter.match({
  "location": "InventorySteps.o_sistema_devera_mostrar_nenhum_numero_no_carrinho()"
});
formatter.result({
  "duration": 30027890100,
  "status": "passed"
});
formatter.after({
  "duration": 787820400,
  "status": "passed"
});
formatter.before({
  "duration": 1553288400,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 430570800,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 1266149700,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Adicionar todos os itens ao carrinho",
  "description": "",
  "id": "inventario;adicionar-todos-os-itens-ao-carrinho",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 19,
      "name": "@Carrinho"
    },
    {
      "line": 19,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 21,
  "name": "clicar para adicionar todos os itens ao carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 22,
  "name": "o sistema devera mostrar no carrinho o numero 6",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_para_adicionar_todos_os_itens_ao_carrinho()"
});
formatter.result({
  "duration": 479403500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "6",
      "offset": 46
    }
  ],
  "location": "InventorySteps.o_sistema_devera_mostrar_no_carrinho_o_numero(int)"
});
formatter.result({
  "duration": 40307000,
  "status": "passed"
});
formatter.after({
  "duration": 892892000,
  "status": "passed"
});
formatter.before({
  "duration": 1525381300,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 497378200,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 782345700,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Remover todos os itens ao carrinho",
  "description": "",
  "id": "inventario;remover-todos-os-itens-ao-carrinho",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 24,
      "name": "@Carrinho"
    },
    {
      "line": 24,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "clicar para adicionar todos os itens ao carrinho",
  "keyword": "Quando "
});
formatter.step({
  "line": 27,
  "name": "o sistema devera mostrar nenhum numero no carrinho",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_para_adicionar_todos_os_itens_ao_carrinho()"
});
formatter.result({
  "duration": 761329500,
  "status": "passed"
});
formatter.match({
  "location": "InventorySteps.o_sistema_devera_mostrar_nenhum_numero_no_carrinho()"
});
formatter.result({
  "duration": 30013314900,
  "status": "passed"
});
formatter.after({
  "duration": 838040900,
  "status": "passed"
});
formatter.uri("Features/Login.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Login",
  "description": "",
  "id": "login",
  "keyword": "Funcionalidade",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    }
  ]
});
formatter.scenarioOutline({
  "line": 11,
  "name": "Realizar Login com Sucesso",
  "description": "",
  "id": "login;realizar-login-com-sucesso",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 10,
      "name": "@RealizarLogin"
    },
    {
      "line": 10,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "informar o campo Username como \"\u003cusuario\u003e\"",
  "keyword": "Quando "
});
formatter.step({
  "line": 13,
  "name": "informar o campo Password como \"\u003csenha\u003e\"",
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "o sistema devera autorizar o login, exibindo pagina do Inventario",
  "keyword": "Entao "
});
formatter.examples({
  "line": 17,
  "name": "",
  "description": "",
  "id": "login;realizar-login-com-sucesso;",
  "rows": [
    {
      "cells": [
        "usuario",
        "senha"
      ],
      "line": 18,
      "id": "login;realizar-login-com-sucesso;;1"
    },
    {
      "cells": [
        "standard_user",
        "secret_sauce"
      ],
      "line": 19,
      "id": "login;realizar-login-com-sucesso;;2"
    },
    {
      "cells": [
        "problem_user",
        "secret_sauce"
      ],
      "line": 20,
      "id": "login;realizar-login-com-sucesso;;3"
    },
    {
      "cells": [
        "performance_glitch_user",
        "secret_sauce"
      ],
      "line": 21,
      "id": "login;realizar-login-com-sucesso;;4"
    }
  ],
  "keyword": "Exemplos"
});
formatter.before({
  "duration": 1620438500,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 461585500,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Realizar Login com Sucesso",
  "description": "",
  "id": "login;realizar-login-com-sucesso;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 10,
      "name": "@RealizarLogin"
    },
    {
      "line": 10,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "informar o campo Username como \"standard_user\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 13,
  "name": "informar o campo Password como \"secret_sauce\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "o sistema devera autorizar o login, exibindo pagina do Inventario",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "standard_user",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 290535900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "secret_sauce",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 196260800,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 199178700,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_devera_autorizar_o_login_exibindo_pagina_contendo_o_Dashboard()"
});
formatter.result({
  "duration": 229605700,
  "status": "passed"
});
formatter.after({
  "duration": 893918100,
  "status": "passed"
});
formatter.before({
  "duration": 1584772800,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 470890300,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Realizar Login com Sucesso",
  "description": "",
  "id": "login;realizar-login-com-sucesso;;3",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 10,
      "name": "@RealizarLogin"
    },
    {
      "line": 10,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "informar o campo Username como \"problem_user\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 13,
  "name": "informar o campo Password como \"secret_sauce\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "o sistema devera autorizar o login, exibindo pagina do Inventario",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "problem_user",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 324781800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "secret_sauce",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 154412300,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 221630300,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_devera_autorizar_o_login_exibindo_pagina_contendo_o_Dashboard()"
});
formatter.result({
  "duration": 143487100,
  "status": "passed"
});
formatter.after({
  "duration": 838709900,
  "status": "passed"
});
formatter.before({
  "duration": 1450193000,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 461530500,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Realizar Login com Sucesso",
  "description": "",
  "id": "login;realizar-login-com-sucesso;;4",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 10,
      "name": "@RealizarLogin"
    },
    {
      "line": 10,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "informar o campo Username como \"performance_glitch_user\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 13,
  "name": "informar o campo Password como \"secret_sauce\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "o sistema devera autorizar o login, exibindo pagina do Inventario",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "performance_glitch_user",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 301249800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "secret_sauce",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 189524700,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 5180461500,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_devera_autorizar_o_login_exibindo_pagina_contendo_o_Dashboard()"
});
formatter.result({
  "duration": 547095400,
  "status": "passed"
});
formatter.after({
  "duration": 982252000,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 24,
  "name": "Tentar realizar Login com senha errada",
  "description": "",
  "id": "login;tentar-realizar-login-com-senha-errada",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 23,
      "name": "@RealizarLogin"
    },
    {
      "line": 23,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "informar o campo Username como \"\u003cusuario\u003e\"",
  "keyword": "Quando "
});
formatter.step({
  "line": 26,
  "name": "informar o campo Password como \"\u003csenha\u003e\"",
  "keyword": "E "
});
formatter.step({
  "line": 27,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 28,
  "name": "o sistema nao devera autorizar o login, exibindo mensagem de login invalido",
  "keyword": "Entao "
});
formatter.examples({
  "line": 30,
  "name": "",
  "description": "",
  "id": "login;tentar-realizar-login-com-senha-errada;",
  "rows": [
    {
      "cells": [
        "usuario",
        "senha"
      ],
      "line": 31,
      "id": "login;tentar-realizar-login-com-senha-errada;;1"
    },
    {
      "cells": [
        "standard_user",
        "senha_errada"
      ],
      "line": 32,
      "id": "login;tentar-realizar-login-com-senha-errada;;2"
    }
  ],
  "keyword": "Exemplos"
});
formatter.before({
  "duration": 1653299200,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 441478600,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Tentar realizar Login com senha errada",
  "description": "",
  "id": "login;tentar-realizar-login-com-senha-errada;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 23,
      "name": "@RealizarLogin"
    },
    {
      "line": 23,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "informar o campo Username como \"standard_user\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 26,
  "name": "informar o campo Password como \"senha_errada\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 27,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 28,
  "name": "o sistema nao devera autorizar o login, exibindo mensagem de login invalido",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "standard_user",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 288412000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "senha_errada",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 152837100,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 102589800,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_nao_devera_autorizar_o_login_exibindo_mensagem_de_login_invalido()"
});
formatter.result({
  "duration": 37437400,
  "status": "passed"
});
formatter.after({
  "duration": 815438900,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 35,
  "name": "Tentar realizar Login com usuario bloqueado",
  "description": "",
  "id": "login;tentar-realizar-login-com-usuario-bloqueado",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 34,
      "name": "@RealizarLogin"
    },
    {
      "line": 34,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 36,
  "name": "informar o campo Username como \"\u003cusuario\u003e\"",
  "keyword": "Quando "
});
formatter.step({
  "line": 37,
  "name": "informar o campo Password como \"\u003csenha\u003e\"",
  "keyword": "E "
});
formatter.step({
  "line": 38,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 39,
  "name": "o sistema nao devera autorizar o login, exibindo mensagem de usuario bloqueado",
  "keyword": "Entao "
});
formatter.examples({
  "line": 41,
  "name": "",
  "description": "",
  "id": "login;tentar-realizar-login-com-usuario-bloqueado;",
  "rows": [
    {
      "cells": [
        "usuario",
        "senha"
      ],
      "line": 42,
      "id": "login;tentar-realizar-login-com-usuario-bloqueado;;1"
    },
    {
      "cells": [
        "locked_out_user",
        "secret_sauce"
      ],
      "line": 43,
      "id": "login;tentar-realizar-login-com-usuario-bloqueado;;2"
    }
  ],
  "keyword": "Exemplos"
});
formatter.before({
  "duration": 1563790300,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 449767700,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "Tentar realizar Login com usuario bloqueado",
  "description": "",
  "id": "login;tentar-realizar-login-com-usuario-bloqueado;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 34,
      "name": "@RealizarLogin"
    },
    {
      "line": 34,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 36,
  "name": "informar o campo Username como \"locked_out_user\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 37,
  "name": "informar o campo Password como \"secret_sauce\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 38,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 39,
  "name": "o sistema nao devera autorizar o login, exibindo mensagem de usuario bloqueado",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "locked_out_user",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 363765500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "secret_sauce",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 139442200,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 101549500,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_nao_devera_autorizar_o_login_exibindo_mensagem_de_usuario_bloqueado()"
});
formatter.result({
  "duration": 34603100,
  "status": "passed"
});
formatter.after({
  "duration": 791873900,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 46,
  "name": "Tentar realizar Login sem senha",
  "description": "",
  "id": "login;tentar-realizar-login-sem-senha",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 45,
      "name": "@RealizarLogin"
    },
    {
      "line": 45,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 47,
  "name": "informar o campo Username como \"\u003cusuario\u003e\"",
  "keyword": "Quando "
});
formatter.step({
  "line": 48,
  "name": "informar o campo Password como \"\u003csenha\u003e\"",
  "keyword": "E "
});
formatter.step({
  "line": 49,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 50,
  "name": "o sistema nao devera autorizar o login, exibindo senha requerida",
  "keyword": "Entao "
});
formatter.examples({
  "line": 52,
  "name": "",
  "description": "",
  "id": "login;tentar-realizar-login-sem-senha;",
  "rows": [
    {
      "cells": [
        "usuario",
        "senha"
      ],
      "line": 53,
      "id": "login;tentar-realizar-login-sem-senha;;1"
    },
    {
      "cells": [
        "teste",
        ""
      ],
      "line": 54,
      "id": "login;tentar-realizar-login-sem-senha;;2"
    }
  ],
  "keyword": "Exemplos"
});
formatter.before({
  "duration": 1602463800,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 434128200,
  "status": "passed"
});
formatter.scenario({
  "line": 54,
  "name": "Tentar realizar Login sem senha",
  "description": "",
  "id": "login;tentar-realizar-login-sem-senha;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 45,
      "name": "@RealizarLogin"
    },
    {
      "line": 45,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 47,
  "name": "informar o campo Username como \"teste\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 48,
  "name": "informar o campo Password como \"\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 49,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 50,
  "name": "o sistema nao devera autorizar o login, exibindo senha requerida",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "teste",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 333150700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 127991300,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 137608200,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_nao_devera_autorizar_o_login_exibindo_senha_requerida()"
});
formatter.result({
  "duration": 55603000,
  "status": "passed"
});
formatter.after({
  "duration": 895520000,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 58,
  "name": "Tentar realizar Login sem usuario",
  "description": "",
  "id": "login;tentar-realizar-login-sem-usuario",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 57,
      "name": "@RealizarLogin"
    },
    {
      "line": 57,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 59,
  "name": "informar o campo Username como \"\u003cusuario\u003e\"",
  "keyword": "Quando "
});
formatter.step({
  "line": 60,
  "name": "informar o campo Password como \"\u003csenha\u003e\"",
  "keyword": "E "
});
formatter.step({
  "line": 61,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 62,
  "name": "o sistema nao devera autorizar o login, exibindo usuario requerido",
  "keyword": "Entao "
});
formatter.examples({
  "line": 64,
  "name": "",
  "description": "",
  "id": "login;tentar-realizar-login-sem-usuario;",
  "rows": [
    {
      "cells": [
        "usuario",
        "senha"
      ],
      "line": 65,
      "id": "login;tentar-realizar-login-sem-usuario;;1"
    },
    {
      "cells": [
        "",
        "teste"
      ],
      "line": 66,
      "id": "login;tentar-realizar-login-sem-usuario;;2"
    }
  ],
  "keyword": "Exemplos"
});
formatter.before({
  "duration": 1642078800,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 8,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 435007200,
  "status": "passed"
});
formatter.scenario({
  "line": 66,
  "name": "Tentar realizar Login sem usuario",
  "description": "",
  "id": "login;tentar-realizar-login-sem-usuario;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenario",
  "tags": [
    {
      "line": 2,
      "name": "@Login"
    },
    {
      "line": 2,
      "name": "@End2End"
    },
    {
      "line": 57,
      "name": "@RealizarLogin"
    },
    {
      "line": 57,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 59,
  "name": "informar o campo Username como \"\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Quando "
});
formatter.step({
  "line": 60,
  "name": "informar o campo Password como \"teste\"",
  "matchedColumns": [
    1
  ],
  "keyword": "E "
});
formatter.step({
  "line": 61,
  "name": "clicar no botao Login",
  "keyword": "E "
});
formatter.step({
  "line": 62,
  "name": "o sistema nao devera autorizar o login, exibindo usuario requerido",
  "keyword": "Entao "
});
formatter.match({
  "arguments": [
    {
      "val": "",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Username_como(String)"
});
formatter.result({
  "duration": 259113200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "teste",
      "offset": 32
    }
  ],
  "location": "LoginSteps.informar_o_campo_Password_como(String)"
});
formatter.result({
  "duration": 231575700,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.clicar_no_botao_Login()"
});
formatter.result({
  "duration": 98124400,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.o_sistema_nao_devera_autorizar_o_login_exibindo_usuario_requerido()"
});
formatter.result({
  "duration": 33699200,
  "status": "passed"
});
formatter.after({
  "duration": 795375400,
  "status": "passed"
});
formatter.uri("Features/Logout.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Logout",
  "description": "",
  "id": "logout",
  "keyword": "Funcionalidade",
  "tags": [
    {
      "line": 2,
      "name": "@Logout"
    },
    {
      "line": 2,
      "name": "@End2End"
    }
  ]
});
formatter.before({
  "duration": 1663266700,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 6,
  "name": "que o usuario esteja na pagina principal do sistema",
  "keyword": "Dado "
});
formatter.step({
  "line": 7,
  "name": "que usuario esteja logado",
  "keyword": "E "
});
formatter.match({
  "location": "LoginSteps.que_o_usuario_esteja_na_pagina_principal_do_sistema()"
});
formatter.result({
  "duration": 410734400,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.que_usuario_esteja_logado()"
});
formatter.result({
  "duration": 1337376500,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Realizar Logout com Sucesso",
  "description": "",
  "id": "logout;realizar-logout-com-sucesso",
  "type": "scenario",
  "keyword": "Cenario",
  "tags": [
    {
      "line": 9,
      "name": "@FuncaoLogout"
    },
    {
      "line": 9,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "clicar no botao Menu",
  "keyword": "Quando "
});
formatter.step({
  "line": 12,
  "name": "clicar no botao Logout",
  "keyword": "E "
});
formatter.step({
  "line": 13,
  "name": "o sistema devera returnar a pagina de Login",
  "keyword": "Entao "
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_Menu()"
});
formatter.result({
  "duration": 95629800,
  "status": "passed"
});
formatter.match({
  "location": "InventorySteps.clicar_no_botao_Logout()"
});
formatter.result({
  "duration": 629351400,
  "status": "passed"
});
formatter.match({
  "location": "InventorySteps.o_sistema_devera_returnar_a_pagina_de_Login()"
});
formatter.result({
  "duration": 51670100,
  "status": "passed"
});
formatter.after({
  "duration": 843030500,
  "status": "passed"
});
});
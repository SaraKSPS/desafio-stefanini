package pageobjects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utils.MetodosUteis;

public class InventoryPage extends MetodosUteis {

	protected WebDriver driver;
	
	public InventoryPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (how = How.ID, using = "shopping_cart_container")
	private WebElement btnCarrinho;
	
	@FindBy (how = How.ID, using = "react-burger-menu-btn")
	private WebElement btnMenu;
	
	@FindBy (how = How.ID, using = "logout_sidebar_link")
	private WebElement btnLogout;
	
	@FindBy (how = How.ID, using = "item_4_title_link")
	private WebElement detalhesBackpack;
	
	@FindBy (how = How.ID, using = "add-to-cart-sauce-labs-backpack")
	private WebElement adicionaBackpack;
	
	@FindBy (how = How.ID, using = "add-to-cart-sauce-labs-bike-light")
	private WebElement adicionaBikelight;
	
	@FindBy (how = How.ID, using = "add-to-cart-sauce-labs-bolt-t-shirt")
	private WebElement adicionaBolt;
	
	@FindBy (how = How.ID, using = "add-to-cart-sauce-labs-fleece-jacket")
	private WebElement adicionaJacket;
	
	@FindBy (how = How.ID, using = "add-to-cart-sauce-labs-onesie")
	private WebElement adicionaOnesie;
	
	@FindBy (how = How.ID, using = "add-to-cart-test.allthethings()-t-shirt-(red)")
	private WebElement adicionaCamisaAll;
	
	@FindBy (how = How.CLASS_NAME, using = "shopping_cart_badge")
	private WebElement quantidadeItensNoCarrinho;
	
	
	public WebElement botaoCarrinho() {
		return btnCarrinho;
	}
	
	public void validarTelaInventario() {
		esperarElemento(btnCarrinho);
		assertTrue(btnCarrinho.isDisplayed());
	}

	public void clicarBotaoMenu() {
		esperarElemento(btnMenu);
		btnMenu.click();		
	}

	public void clicarBotaoLogout() {
		esperarElemento(btnLogout);
		btnLogout.click();
	}

	public void checarCarrinhoVazio() {
		assert(driver.findElements(By.id("shopping_cart_badge")).isEmpty());
	}
	

	public void checarNumeroDoCarrinho(int numero) {
		assertEquals((quantidadeItensNoCarrinho.getText()), Integer.toString(numero));
	}
	
	public void clicarCarrinho() {
		btnCarrinho.click();
	}
	
	public void clicarUmItem() {
		adicionaBackpack.click();
	}

	public void clicarTodosOsItems() {
		adicionaBackpack.click();
		adicionaBikelight.click();
		adicionaJacket.click();
		adicionaBolt.click();
		adicionaOnesie.click();
		adicionaCamisaAll.click();
	}

	public void clicarDetalhesUmItem() {
		detalhesBackpack.click();
	}



}

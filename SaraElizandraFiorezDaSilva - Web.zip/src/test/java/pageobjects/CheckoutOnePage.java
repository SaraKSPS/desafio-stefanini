package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utils.MetodosUteis;

public class CheckoutOnePage extends MetodosUteis {
protected WebDriver driver;
	
	public CheckoutOnePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (how = How.ID, using = "first-name")
	private WebElement nome;
	
	@FindBy (how = How.ID, using = "last-name")
	private WebElement sobrenome;
	
	@FindBy (how = How.ID, using = "postal-code")
	private WebElement cep;
	
	@FindBy (how = How.ID, using = "continue")
	private WebElement continuar;
	
	public void inserirNome(String texto) {
		nome.sendKeys(texto);
	}
	
	public void inserirSobrenome(String texto) {
		sobrenome.sendKeys(texto);
	}
	
	public void inserirCep(String texto) {
		cep.sendKeys(texto);
	}
	
	public void clicarContinuar() {
		continuar.click();
	}

	
}

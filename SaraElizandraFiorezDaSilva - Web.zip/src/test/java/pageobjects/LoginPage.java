package pageobjects;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import utils.MetodosUteis;

public class LoginPage extends MetodosUteis {
	
	protected WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (how = How.ID, using = "user-name")
	private WebElement usuario;
	
	@FindBy (how = How.ID, using = "password")
	private WebElement senha;
	
	@FindBy (how = How.ID, using = "login-button")
	private WebElement btnLogin;
	
	@FindBy (how = How.XPATH, using = "//*[contains(text(), 'Epic sadface: Username and password do not match any user in this service')]")
	private WebElement mensagemErroLogin;
	
	@FindBy (how = How.XPATH, using = "//*[contains(text(), 'Epic sadface: Sorry, this user has been locked out.')]")
	private WebElement mensagemUsuarioBloqueado;
	
	@FindBy (how = How.XPATH, using = "//*[contains(text(), 'Epic sadface: Username is required')]")
	private WebElement mensagemUsuarioRequerido;
	
	@FindBy (how = How.XPATH, using = "//*[contains(text(), 'Epic sadface: Password is required')]")
	private WebElement mensagemSenhaRequerida;
	
	public void preencherUsuario(String nomeUsuario) {
		esperarElemento(usuario);
		usuario.sendKeys(nomeUsuario);
	}
	
	public void preencherSenha(String senhaUsuario) {
		esperarElemento(senha);
		senha.sendKeys(senhaUsuario);
	}
	
	public void clicarBotaoLogin() {
		esperarElemento(btnLogin);
		btnLogin.click();
	}

	public void validarSenhaInvalida() {
		assertTrue(mensagemErroLogin.isDisplayed());
	}

	public void validarUsuarioBloqueado() {
		assertTrue(mensagemUsuarioBloqueado.isDisplayed());
	}

	public void validarUsuarioRequerido() {
		assertTrue(mensagemUsuarioRequerido.isDisplayed());
	}
	
	public void validarSenhaRequerida() {
		assertTrue(mensagemSenhaRequerida.isDisplayed());
	}

	public void validarTelaLogin() {
		esperarElemento(usuario);
		assertTrue(usuario.isDisplayed());
	}
	
}


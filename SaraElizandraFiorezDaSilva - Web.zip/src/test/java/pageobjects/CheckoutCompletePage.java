package pageobjects;

import static org.junit.Assert.assertFalse;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utils.MetodosUteis;

public class CheckoutCompletePage extends MetodosUteis {
protected WebDriver driver;
	
	public CheckoutCompletePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[contains(text(), 'THANK YOU FOR YOUR ORDER')]")
	private WebElement mensagemOrdemSucesso;
	
	public void verificarOrdemSucesso() {
		esperarElemento(mensagemOrdemSucesso);
		assert(mensagemOrdemSucesso.isDisplayed());
	}

	public void verificarOrdemInsucesso() {		
		assertFalse(mensagemOrdemSucesso.isDisplayed());
	}
	
}

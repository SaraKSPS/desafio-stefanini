package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utils.MetodosUteis;

public class CheckoutTwoPage extends MetodosUteis {
protected WebDriver driver;
	
	public CheckoutTwoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (how = How.ID, using = "finish")
	private WebElement finalizar;
	
	@FindBy (how = How.CLASS_NAME, using = "summary_tax_label")
	private WebElement totalImposto;
	
	@FindBy (how = How.CLASS_NAME, using = "summary_total_label")
	private WebElement total;
	
	public void verificarTotalBackPack() {
		// imposto: 8% do valor do item
		assert(totalImposto.getText().contains("2.40"));
		assert(total.getText().contains("32.39"));
	}
	
	public void verificarTotalCheio() {
		// imposto: 8% do valor do item
		assert(totalImposto.getText().contains("10.40"));
		assert(total.getText().contains("140.34"));
	}
	
	public void clicarFinalizar() {
		finalizar.click();
	}
	
}

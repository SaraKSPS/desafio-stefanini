package stepdefinitions;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.Quando;
import pageobjects.CartPage;
import pageobjects.CheckoutCompletePage;
import pageobjects.CheckoutOnePage;
import pageobjects.CheckoutTwoPage;
import pageobjects.InventoryPage;

public class CheckoutSteps {

	WebDriver driver = Hooks.getDriver();

	@Quando("^clicar no icone do carrinho$")
	public void clicar_no_icone_do_carrinho() {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarCarrinho();
	}

	@Quando("^clicar em Checkout$")
	public void clicar_em_Checkout() throws Throwable {
		CartPage cp = new CartPage(driver);
		cp.clicarCheckout();
	}

	@Quando("^colocar valores validos para nome, sobrenome e cep$")
	public void colocar_valores_validos_para_nome_sobrenome_e_cep() throws Throwable {
		CheckoutOnePage cop = new CheckoutOnePage(driver);
		cop.inserirNome("valido");
		cop.inserirSobrenome("valido");
		cop.inserirCep("12390");
	}

	@Quando("^clicar para prosseguir$")
	public void clicar_para_prosseguir() throws Throwable {
		CheckoutOnePage cop = new CheckoutOnePage(driver);
		cop.clicarContinuar();
	}

	@Entao("^a tela de checkout overview deve ser mostrada com o valor total correto do item$")
	public void a_tela_de_checkout_overview_deve_ser_mostrada_com_o_valor_total_correto_do_item() throws Throwable {
		CheckoutTwoPage ctp = new CheckoutTwoPage(driver);
		ctp.verificarTotalBackPack();
	}

	@Entao("^a tela de checkout overview deve ser mostrada com o valor total correto de todos os itens$")
	public void a_tela_de_checkout_overview_deve_ser_mostrada_com_o_valor_total_correto_de_todos_os_itens()
			throws Throwable {
		CheckoutTwoPage ctp = new CheckoutTwoPage(driver);
		ctp.verificarTotalCheio();
	}

	@Quando("^clicar para concluir o pedido$")
	public void clicar_para_concluir_o_pedido() throws Throwable {
		CheckoutTwoPage ccp = new CheckoutTwoPage(driver);
		ccp.clicarFinalizar();
	}

	@Entao("^a tela de sucesso ao realizar ordem deve ser exibida$")
	public void a_tela_de_sucesso_ao_realizar_ordem_deve_ser_exibida() throws Throwable {
		CheckoutCompletePage ccp = new CheckoutCompletePage(driver);
		ccp.verificarOrdemSucesso();
	}


	@Entao("^a tela de sucesso ao realizar ordem nao deveria ser exibida$")
	public void aTelaDeSucessoAoRealizarOrdemNaoDeveriaSerExibida() throws Throwable {
		CheckoutCompletePage ccp = new CheckoutCompletePage(driver);
		ccp.verificarOrdemInsucesso();
	}

}

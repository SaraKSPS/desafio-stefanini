package stepdefinitions;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.pt.E;
import cucumber.api.java.pt.Quando;
import pageobjects.DetailsPage;
import pageobjects.InventoryPage;

public class DetailsSteps {
	
	WebDriver driver = Hooks.getDriver();

	@E("^tela de algum item esteja sendo exibida$")
	public void telaDeAlgumItemEstejaSendoExibida() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarDetalhesUmItem();
	}
	


	@Quando("^clica para adicionar item pelos detalhes$")
	public void clicaParaAdicionarItemPelosDetalhes() throws Throwable {
		DetailsPage dp =  new DetailsPage(driver);
		dp.adicionarBackPack();
	}
}

package stepdefinitions;

import org.openqa.selenium.WebDriver;
import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.Quando;
import pageobjects.InventoryPage;
import pageobjects.LoginPage;

public class InventorySteps {

	WebDriver driver = Hooks.getDriver();

	@Quando("^clicar no botao Menu$")
	public void clicar_no_botao_Menu() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarBotaoMenu();
	}

	@Quando("^clicar no botao Logout$")
	public void clicar_no_botao_Logout() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarBotaoLogout();
	}

	@Entao("^o sistema devera returnar a pagina de Login$")
	public void o_sistema_devera_returnar_a_pagina_de_Login() throws Throwable {
		LoginPage lp = new LoginPage(driver);
		lp.validarTelaLogin();
	}

	@Quando("^clicar no botao de adicionar um item no carrinho$")
	public void clicar_no_botao_de_adicionar_um_item_no_carrinho() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarUmItem();
	}

	@Entao("^o sistema devera mostrar no carrinho o numero (\\d+)$")
	public void o_sistema_devera_mostrar_no_carrinho_o_numero(int numero) throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.checarNumeroDoCarrinho(numero);
	}

	@Entao("^o sistema devera mostrar nenhum numero no carrinho$")
	public void o_sistema_devera_mostrar_nenhum_numero_no_carrinho() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.checarCarrinhoVazio();
	}

	@Quando("^clicar para adicionar todos os itens ao carrinho$")
	public void clicar_para_adicionar_todos_os_itens_ao_carrinho() throws Throwable {
		InventoryPage ip = new InventoryPage(driver);
		ip.clicarTodosOsItems();
	}

}
